declare interface IFieldCostumizerFieldCustomizerStrings {
  Title: string;
}

declare module 'FieldCostumizerFieldCustomizerStrings' {
  const strings: IFieldCostumizerFieldCustomizerStrings;
  export = strings;
}
