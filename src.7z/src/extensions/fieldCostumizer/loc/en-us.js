define([], function() {
  return {
    "Title": "FieldCostumizerFieldCustomizer"
  }
});