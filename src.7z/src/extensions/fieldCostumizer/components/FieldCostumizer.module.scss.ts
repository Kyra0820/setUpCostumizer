/* tslint:disable */
require("./FieldCostumizer.module.css");
const styles = {
  fieldCostumizer: 'fieldCostumizer_41a64502'
};

export default styles;
/* tslint:enable */