/* tslint:disable */
require("./SetUpCostumizer.module.css");
const styles = {
  setUpCostumizer: 'setUpCostumizer_12312d62',
  teams: 'teams_12312d62',
  welcome: 'welcome_12312d62',
  welcomeImage: 'welcomeImage_12312d62',
  links: 'links_12312d62'
};

export default styles;
/* tslint:enable */