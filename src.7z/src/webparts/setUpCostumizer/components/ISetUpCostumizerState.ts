export interface ISetUpCustomizerState {
    isLoading?: boolean;
    isWorking?: boolean;

    componentID?: string;
    isFieldAdded?: boolean;
    isPanelOpen?: boolean;
    
}