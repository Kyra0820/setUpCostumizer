import { BaseComponentContext } from '@microsoft/sp-component-base';
import { SPFx, spfi, SPFI } from '@pnp/sp';
import "@pnp/sp/webs";
import "@pnp/sp/fields";
import "@pnp/sp/lists"
import "@pnp/sp/items";
import "@pnp/sp/views";
import { AddFieldOptions, IFieldAddResult } from '@pnp/sp/fields';
import { SPHttpClient, SPHttpClientResponse} from '@microsoft/sp-http';

/**
 * Singleton class SharePoint hívásokhozs
 */
export default class SPService {
    private static _current: SPService;
    private _spfi: SPFI;
    private _sphttpclient: SPHttpClient;
    public static get current(): SPService {
        if (!this._current) {
            throw new Error("SPService not initialized");
        }
        return this._current;
    }

    /**
     * Instance inicializálása, pnp inicializálása
     * Minden belépési pontból meg kell hívni, azaz web part, field customzer, application customizer, stb
     * @param context Base Compoenent Context
     */
    public ctx : BaseComponentContext;
    public static init(context: BaseComponentContext): void {
        if (!this._current) {
            this._current = new SPService();
            this._current._spfi = spfi().using(SPFx(context));
            this._current._sphttpclient = context.spHttpClient;
        }
    }

    

    /**
     * Oszlop hozzáadása a listához
     * Hozzáadja az összes content type-hoz, a default view-hoz és a megadott static névvel hozza létre az oszlopot
     * @returns 
     */
    public async AddColumnToList(): Promise<IFieldAddResult> {

        // itt ha megnézed a createFieldAsXml leírását (F12) akkor látod, hogy kétfajta paramétert adhatunk meg neki, string-et vagy objectet
        // object esetében pedig az Options paraméterrel lehet hinteket adni (típusa: AddFieldOptions) és azt érdemes tudni róla, hogy az egyes enum értékeket össze lehet adni
        // azaz ha szeretnénk, hogy a megadott static névvel jöjjön létre az oszlop és a default view-hoz is hozzá legyen adva, akkor az alábbiakat kell használnunk:
        // AddToAllContentTypes + AddFieldInternalNameHint + AddFieldToDefaultView

        // valamint felhívnám a figyelmet a visszatérési érték figyelésére is (legalább böngészőben nézd meg a network fülön, hogy mit ad vissza)

        // ezeket persze szebb paraméterként beadni, de most így egyszerűbb
        const listRelativeUrl = "/sites/Adatlistak/Lists/Tantrgyak";
        const xml = `<Field Type="Text" DisplayName="CustomColumn" StaticName="CustomColumn" Name="CustomColumn" />`;
       
        return this._spfi.web.getList(listRelativeUrl).fields.createFieldAsXml(
            {
                SchemaXml: xml,
                Options: AddFieldOptions.AddToAllContentTypes
                    + AddFieldOptions.AddFieldInternalNameHint
                    + AddFieldOptions.AddFieldToDefaultView
            }
        );
    }

    /**
     * Oszlop hozzáadása a default view-hoz
     * @returns 
     */
    public async AddColumnToView(): Promise<void> {
        // ezeket persze szebb paraméterként beadni, de most így egyszerűbb
        const listRelativeUrl = "/sites/Adatlistak/Lists/Tantrgyak";
        const fieldName = "CustomColumn"

        // itt nincs visszatérési érték, de ha szépen szeretnénk csinálni akkor készülni kell rá, hogy dobhat exception-t
        return this._spfi.web.getList(listRelativeUrl).defaultView.fields.add(fieldName);
    }

    public async CheckFieldOnList(listRelativeUrl: string, fieldName: string): Promise<boolean> {
        try {
            // Lekéri az adott oszlopot a megadott listán
            const field = await this._spfi.web.getList(listRelativeUrl).fields.getByInternalNameOrTitle(fieldName)();
            // Ha a field objektum létezik és nem üres, az oszlop létezik
            return !!field;
        } catch (error) {
            // Ha a field nem létezik vagy más hiba történik, false-szal tér vissza
            console.error('Hiba történt az oszlop ellenőrzése közben:', error);
            return false;
        }
    }
    
    public async GetFieldId(listRelativeUrl: string, fieldName: string): Promise<string> {
    try {
        const field = await this._spfi.web.getList(listRelativeUrl).fields.getByInternalNameOrTitle(fieldName).select('Id')();
        return field.Id;
    } catch (error) {
        console.error('Error getting field ID:', error);
        return '';
    }
}

    
public async AddGearIconFieldCustomizerToList(columnName: string): Promise<void> {
    try {
      //const listRelativeUrl = "/sites/Adatlistak/Lists/Tantrgyak";
      const fieldCustomizerId = "9add62cc-116d-4e45-9691-61feda79f72a"; 
    const listName = "Tantárgyak";
      const body: string = JSON.stringify({
        ClientSideComponentId: fieldCustomizerId
        
      });
      this._sphttpclient.get(`https://kyra1025.sharepoint.com/sites/Adatlistak/_api/web/lists/getbytitle('${listName}')/fields/getbyinternalnameortitle('${columnName}')`,  
      SPHttpClient.configurations.v1)  
      .then((response: SPHttpClientResponse) => {  
        response.json().then((responseJSON: any) => {  
          console.log(responseJSON);  
        });  
      });  
      await fetch(`https://kyra1025.sharepoint.com/sites/Adatlistak/_api/web/lists/getbytitle('${listName}')/fields/getbyinternalnameortitle('${columnName}')`, {
        method: 'POST',
        body: body,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'odata-version': ''
        }
      });
      
      console.log(`Field Customizer successfully added to column ${columnName}`);
    } catch (error) {
      console.error('Error adding Gear Icon Field Customizer:', error);
      throw error;
    }
    
  }
  }
  
